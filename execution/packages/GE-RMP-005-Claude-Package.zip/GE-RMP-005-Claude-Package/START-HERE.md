# Claude Package

Implementation Authority

GE-RMP-005

Repository

APP-001

Authority Stream

—

Production Surface

CTBC Recruitment Experience Enhancement

--------------------------------------------------

Package Is the Contract (PIC)

This package is the complete implementation contract.

Claude SHALL consume this package as the sole authoritative implementation contract.

Execution SHALL synchronize using the governance artifacts contained within this package.

--------------------------------------------------

Package Generated

2026-07-14 14:35 UTC

--------------------------------------------------

Execution

Synchronize all governance artifacts in this package before proceeding.

Begin with the Claude Instruction Brief in governance/cib/generated/.
