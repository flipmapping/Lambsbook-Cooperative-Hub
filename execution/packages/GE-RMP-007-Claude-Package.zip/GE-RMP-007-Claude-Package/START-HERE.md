# Claude Package

Implementation Authority

GE-RMP-007

Repository

Growth Engine

Authority Stream

GE

Production Surface

Applicant Document Center

--------------------------------------------------

Package Is the Contract (PIC)

This package is the complete implementation contract.

Claude SHALL consume this package as the sole authoritative implementation contract.

Execution SHALL synchronize using the governance artifacts contained within this package.

--------------------------------------------------

Package Generated

2026-07-09 08:51 UTC

--------------------------------------------------

Execution

Synchronize all governance artifacts in this package before proceeding.

Begin with the Claude Instruction Brief in governance/cib/generated/.
