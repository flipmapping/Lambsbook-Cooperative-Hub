import { Router, Request, Response, text as expressText, raw as expressRaw } from 'express';
import type { AuthenticatedRequest } from '../types/requestContext';
import { supabaseDAL } from '../lib';
import { createAuthenticatedClient } from '../lib/supabase-member-client';
import { attachUserContext } from "../middleware/attachUserContext";
import type {
  ProgramInsert, ProgramUpdate,
  ProgramEligibilityInsert,
  MemberUpdate,
  EarningUpdate,
  TutorUpdate,
  MembershipStatus, ActivityStatus, TutorStatus
} from '../lib/supabase-types';

import { importProspectsFromCsv } from '../services/csv-import';
import { importProspectsFromExcel } from '../services/csv-import';
import { sendZaloBroadcast } from '../services/zalo-transport';

const router = Router();

const INACTIVITY_THRESHOLD_MONTHS = parseInt(process.env.INACTIVITY_THRESHOLD_MONTHS || '3', 10);

router.get('/programs', async (_req: Request, res: Response) => {
  try {
    const programs = await supabaseDAL.getAllPrograms();
    res.json(programs);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to fetch programs';
    res.status(500).json({ error: message });
  }
});

router.post('/programs', async (req: Request, res: Response) => {
  try {
    const data: ProgramInsert = {
      program_id: req.body.program_id,
      name: req.body.name,
      sbu_id: req.body.sbu_id ?? req.body.sbu,
      program_type: req.body.program_type ?? null,
      description: req.body.description ?? null,
      revenue_base: req.body.revenue_base,
      trigger_condition: req.body.trigger_condition,
      is_active: req.body.is_active ?? true,
    };
    const program = await supabaseDAL.createProgram(data);
    res.status(201).json(program);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to create program';
    res.status(500).json({ error: message });
  }
});

router.patch('/programs/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const data: ProgramUpdate = {};
    if (req.body.program_id !== undefined) data.program_id = req.body.program_id;
    if (req.body.name !== undefined) data.name = req.body.name;
    if (req.body.sbu_id !== undefined) data.sbu_id = req.body.sbu_id;
    else if (req.body.sbu !== undefined) data.sbu_id = req.body.sbu;
    if (req.body.program_type !== undefined) data.program_type = req.body.program_type;
    if (req.body.description !== undefined) data.description = req.body.description;
    if (req.body.revenue_base !== undefined) data.revenue_base = req.body.revenue_base;
    if (req.body.trigger_condition !== undefined) data.trigger_condition = req.body.trigger_condition;
    if (req.body.is_active !== undefined) data.is_active = req.body.is_active;

    const program = await supabaseDAL.updateProgram(id, data);
    res.json(program);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to update program';
    res.status(500).json({ error: message });
  }
});

router.patch('/programs/:id/activate', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const program = await supabaseDAL.updateProgram(id, { is_active: true });
    res.json(program);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to activate program';
    res.status(500).json({ error: message });
  }
});

router.patch('/programs/:id/deactivate', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const program = await supabaseDAL.updateProgram(id, { is_active: false });
    res.json(program);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to deactivate program';
    res.status(500).json({ error: message });
  }
});

router.get('/program-eligibility', async (req: Request, res: Response) => {
  try {
    const { member_id } = req.query;
    if (member_id && typeof member_id === 'string') {
      const eligibility = await supabaseDAL.getProgramEligibilityByMember(member_id);
      res.json(eligibility);
    } else {
      res.status(400).json({ error: 'member_id query parameter required' });
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to fetch eligibility';
    res.status(500).json({ error: message });
  }
});

router.post('/program-eligibility', async (req: Request, res: Response) => {
  try {
    const member = await supabaseDAL.getMemberById(req.body.member_id);
    if (!member) {
      return res.status(404).json({ error: 'Member not found' });
    }

    const data: ProgramEligibilityInsert = {
      member_id: req.body.member_id,
      program_id: req.body.program_id,
      eligible: req.body.eligible ?? true,
    };
    const eligibility = await supabaseDAL.createProgramEligibility(data);
    res.status(201).json(eligibility);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to create eligibility';
    res.status(500).json({ error: message });
  }
});

router.patch('/program-eligibility/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const eligibility = await supabaseDAL.updateProgramEligibility(id, {
      eligible: req.body.eligible,
    });
    res.json(eligibility);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to update eligibility';
    res.status(500).json({ error: message });
  }
});

router.delete('/program-eligibility/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    await supabaseDAL.deleteProgramEligibility(id);
    res.json({ success: true });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to delete eligibility';
    res.status(500).json({ error: message });
  }
});

router.get('/members', async (req: Request, res: Response) => {
  try {
    let members = await supabaseDAL.getAllMembers();

    const { membership_status, activity_status } = req.query;
    if (membership_status && typeof membership_status === 'string') {
      members = members.filter(m => m.membership_status === membership_status);
    }
    if (activity_status && typeof activity_status === 'string') {
      members = members.filter(m => m.activity_status === activity_status);
    }

    res.json(members);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to fetch members';
    res.status(500).json({ error: message });
  }
});

router.get('/members/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const member = await supabaseDAL.getMemberById(id);
    if (!member) {
      return res.status(404).json({ error: 'Member not found' });
    }
    res.json(member);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to fetch member';
    res.status(500).json({ error: message });
  }
});

router.get('/members/:id/invitees', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const invitees = await supabaseDAL.getDirectInvitees(id);
    res.json(invitees);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to fetch invitees';
    res.status(500).json({ error: message });
  }
});

router.patch('/members/:id/membership', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { membership_status } = req.body as { membership_status: MembershipStatus };

    if (!['free', 'paid'].includes(membership_status)) {
      return res.status(400).json({ error: 'Invalid membership_status' });
    }

    const member = await supabaseDAL.updateMember(id, { membership_status });
    res.json(member);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to update membership';
    res.status(500).json({ error: message });
  }
});

router.patch('/members/:id/activity', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { activity_status } = req.body as { activity_status: ActivityStatus };

    if (!['active', 'inactive'].includes(activity_status)) {
      return res.status(400).json({ error: 'Invalid activity_status' });
    }

    const member = await supabaseDAL.updateMember(id, { activity_status });

    if (activity_status === 'inactive') {
      await supabaseDAL.pauseEarningsForInactiveMember(id);
    } else {
      await supabaseDAL.resumeEarningsForActiveMember(id);
    }

    res.json(member);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to update activity status';
    res.status(500).json({ error: message });
  }
});

router.get('/collaborations', async (_req: Request, res: Response) => {
  try {
    const collaborations = await supabaseDAL.getAllCollaborations();
    res.json(collaborations);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to fetch collaborations';
    res.status(500).json({ error: message });
  }
});

router.get('/activity-config', async (_req: Request, res: Response) => {
  res.json({
    inactivity_threshold_months: INACTIVITY_THRESHOLD_MONTHS,
  });
});

router.post('/activity-decay/check', async (_req: Request, res: Response) => {
  try {
    const members = await supabaseDAL.getAllMembers();
    const thresholdDate = new Date();
    thresholdDate.setMonth(thresholdDate.getMonth() - INACTIVITY_THRESHOLD_MONTHS);

    let deactivatedCount = 0;
    for (const member of members) {
      if (member.activity_status === 'active') {
        const lastActivity = member.last_activity_at ? new Date(member.last_activity_at) : new Date(member.join_date);
        if (lastActivity < thresholdDate) {
          await supabaseDAL.updateMember(member.id, { activity_status: 'inactive' });
          await supabaseDAL.pauseEarningsForInactiveMember(member.id);
          deactivatedCount++;
        }
      }
    }

    res.json({ 
      checked: members.length, 
      deactivated: deactivatedCount,
      threshold_months: INACTIVITY_THRESHOLD_MONTHS 
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to run activity decay check';
    res.status(500).json({ error: message });
  }
});

router.get('/earnings', async (req: Request, res: Response) => {
  try {
    let earnings = await supabaseDAL.getAllEarnings();

    const { member_id, program_id, earning_status, period } = req.query;

    if (member_id && typeof member_id === 'string') {
      earnings = earnings.filter(e => e.member_id === member_id);
    }
    if (program_id && typeof program_id === 'string') {
      earnings = earnings.filter(e => e.program_id === program_id);
    }
    if (earning_status && typeof earning_status === 'string') {
      earnings = earnings.filter(e => e.earning_status === earning_status);
    }
    if (period && typeof period === 'string') {
      earnings = earnings.filter(e => e.period === period);
    }

    res.json(earnings);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to fetch earnings';
    res.status(500).json({ error: message });
  }
});

router.patch('/earnings/:id/pause', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const earning = await supabaseDAL.getEarningById(id);
    if (!earning) {
      return res.status(404).json({ error: 'Earning not found' });
    }
    if (earning.earning_status === 'paid') {
      return res.status(400).json({ error: 'Cannot pause a paid earning' });
    }

    const updated = await supabaseDAL.updateEarning(id, { earning_status: 'paused' });
    res.json(updated);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to pause earning';
    res.status(500).json({ error: message });
  }
});

router.patch('/earnings/:id/resume', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const earning = await supabaseDAL.getEarningById(id);
    if (!earning) {
      return res.status(404).json({ error: 'Earning not found' });
    }
    if (earning.earning_status !== 'paused') {
      return res.status(400).json({ error: 'Only paused earnings can be resumed' });
    }

    const member = await supabaseDAL.getMemberById(earning.member_id);
    if (member && member.activity_status === 'inactive') {
      return res.status(400).json({ error: 'Cannot resume earning for inactive member' });
    }

    const updated = await supabaseDAL.updateEarning(id, { earning_status: 'pending' });
    res.json(updated);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to resume earning';
    res.status(500).json({ error: message });
  }
});

router.get('/tutors', async (req: Request, res: Response) => {
  try {
    const { tutor_status } = req.query;
    let tutors = await supabaseDAL.getAllTutors();

    if (tutor_status && typeof tutor_status === 'string') {
      tutors = tutors.filter(t => t.tutor_status === tutor_status);
    }

    res.json(tutors);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to fetch tutors';
    res.status(500).json({ error: message });
  }
});

router.patch('/tutors/:id/status', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { tutor_status } = req.body as { tutor_status: TutorStatus };

    if (!['unverified', 'verified', 'partner_educator'].includes(tutor_status)) {
      return res.status(400).json({ error: 'Invalid tutor_status' });
    }

    const tutor = await supabaseDAL.updateTutor(id, { tutor_status });
    res.json(tutor);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to update tutor status';
    res.status(500).json({ error: message });
  }
});

router.post('/tutors/check-free-class-requirement', async (_req: Request, res: Response) => {
  try {
    const FREE_CLASS_MINUTES_REQUIRED = 30;
    const tutors = await supabaseDAL.getAllTutors();

    let demotedCount = 0;
    for (const tutor of tutors) {
      if (tutor.tutor_status === 'verified' && tutor.free_class_minutes_last_30_days < FREE_CLASS_MINUTES_REQUIRED) {
        await supabaseDAL.updateTutor(tutor.id, { tutor_status: 'unverified' });
        demotedCount++;
      }
    }

    res.json({ 
      checked: tutors.length, 
      demoted: demotedCount,
      required_minutes: FREE_CLASS_MINUTES_REQUIRED 
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to check free class requirement';
    res.status(500).json({ error: message });
  }
});

router.get('/activity-logs', async (req: Request, res: Response) => {
  try {
    const { member_id, limit } = req.query;
    const limitNum = limit ? parseInt(limit as string, 10) : 500;

    if (member_id && typeof member_id === 'string') {
      const logs = await supabaseDAL.getActivityLogsByMember(member_id, limitNum);
      res.json(logs);
    } else {
      const logs = await supabaseDAL.getAllActivityLogs(limitNum);
      res.json(logs);
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to fetch activity logs';
    res.status(500).json({ error: message });
  }
});

router.get('/stats', async (_req: Request, res: Response) => {
  try {
    const [members, programs, earnings, tutors, collaborations] = await Promise.all([
      supabaseDAL.getAllMembers(),
      supabaseDAL.getAllPrograms(),
      supabaseDAL.getAllEarnings(),
      supabaseDAL.getAllTutors(),
      supabaseDAL.getAllCollaborations(),
    ]);

    res.json({
      members: {
        total: members.length,
        free: members.filter(m => m.membership_status === 'free').length,
        paid: members.filter(m => m.membership_status === 'paid').length,
        active: members.filter(m => m.activity_status === 'active').length,
        inactive: members.filter(m => m.activity_status === 'inactive').length,
      },
      programs: {
        total: programs.length,
        active: programs.filter(p => p.is_active).length,
      },
      earnings: {
        total: earnings.length,
        pending: earnings.filter(e => e.earning_status === 'pending').length,
        paid: earnings.filter(e => e.earning_status === 'paid').length,
        paused: earnings.filter(e => e.earning_status === 'paused').length,
        totalAmount: earnings.reduce((sum, e) => sum + Number(e.amount), 0),
      },
      tutors: {
        total: tutors.length,
        unverified: tutors.filter(t => t.tutor_status === 'unverified').length,
        verified: tutors.filter(t => t.tutor_status === 'verified').length,
        partner_educator: tutors.filter(t => t.tutor_status === 'partner_educator').length,
      },
      collaborations: {
        total: collaborations.length,
        active: collaborations.filter(c => c.status === 'active').length,
      },
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to fetch stats';
    res.status(500).json({ error: message });
  }
});

router.post('/enrollment-payment', attachUserContext, async (req: Request, res: Response) => {
  const authReq = req as AuthenticatedRequest;
  try {
    const user = authReq.user;

    if (!user?.token) {
      return res.status(401).json({ error: 'Missing authorization token' });
    }

    const { member_id, program_id, amount, reference } = req.body;

    if (!member_id || !program_id || amount === undefined) {
      return res.status(400).json({ error: 'member_id, program_id, and amount are required' });
    }

    if (typeof amount !== 'number' || amount <= 0) {
      return res.status(400).json({ error: 'amount must be a positive number' });
    }

    const supabase = createAuthenticatedClient(user.token, 'public');

    const { data, error } = await supabase.rpc(
      'create_program_enrollment_payment_event',
      {
        p_member_id: member_id,
        p_program_id: program_id,
        p_amount: amount,
        p_reference: reference || null,
      }
    );

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    return res.status(201).json({ data });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Failed to create enrollment payment';
    return res.status(500).json({ error: message });
  }
});

// GE-EXEC-004B — Campaign Launch: list imported prospects for the
// Prospect Campaign workflow (table/search/selection binds to this).
// Mirrors the existing getAllMembers/getAllPrograms/getAllTutors/
// getAllCollaborations convention used throughout this router.
router.get('/prospects', async (_req: Request, res: Response) => {
  try {
    const prospects = await supabaseDAL.getAllProspects();
    res.json(prospects);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to fetch prospects';
    res.status(500).json({ error: message });
  }
});

// GE-PIC-001 — CSV Prospect Import
// POST /api/admin/prospects/csv-import
// Body: raw CSV text (Content-Type: text/csv or text/plain)
// Accepts up to 5MB of CSV content via express.text() middleware.
router.post(
  '/prospects/csv-import',
  expressText({ type: ['text/csv', 'text/plain'], limit: '5mb' }),
  async (req: Request, res: Response) => {
    try {
      const csvText: string = req.body;
      if (typeof csvText !== 'string' || !csvText.trim()) {
        return res.status(400).json({ error: 'Request body must be CSV text.' });
      }
      const summary = await importProspectsFromCsv(csvText);
      const status = summary.errors.length > 0 && summary.imported === 0 ? 422 : 200;
      return res.status(status).json(summary);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'CSV import failed';
      return res.status(500).json({ error: message });
    }
  },
);

// GE-EXEC-004B-REV3 — Campaign Operations: delete all prospects.
// Registered before the bulk-delete route since Express matches
// literal path segments ('/prospects/all') ahead of no conflicting
// pattern here, but kept above for readability/ordering clarity.
router.delete('/prospects/all', async (_req: Request, res: Response) => {
  try {
    await supabaseDAL.deleteAllProspects();
    return res.json({ success: true });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to delete all prospects';
    return res.status(500).json({ error: message });
  }
});

// GE-EXEC-004B-REV3 — Campaign Operations: delete selected prospects.
// Body: { ids: string[] }
router.delete('/prospects', async (req: Request, res: Response) => {
  try {
    const ids = req.body?.ids;
    if (!Array.isArray(ids) || ids.some((id) => typeof id !== 'string') || ids.length === 0) {
      return res.status(400).json({ error: 'Request body must include a non-empty "ids" array of strings.' });
    }
    await supabaseDAL.deleteProspects(ids);
    return res.json({ success: true, deleted: ids.length });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to delete prospects';
    return res.status(500).json({ error: message });
  }
});

// GE-EXEC-004B-REV3 — Campaign Operations: Excel (.xlsx/.xls) prospect
// import. Reuses the same row-validation/duplicate-detection/persistence
// pipeline as CSV import (see services/csv-import.ts). Raw binary body,
// same 5MB ceiling as the CSV route.
router.post(
  '/prospects/excel-import',
  expressRaw({
    type: [
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', // .xlsx
      'application/vnd.ms-excel', // .xls (legacy binary format is NOT supported by this parser — see csv-import.ts)
      'application/octet-stream',
    ],
    limit: '5mb',
  }),
  async (req: Request, res: Response) => {
    try {
      const buffer: Buffer = req.body;
      if (!Buffer.isBuffer(buffer) || buffer.length === 0) {
        return res.status(400).json({ error: 'Request body must be binary .xlsx content.' });
      }
      const summary = await importProspectsFromExcel(buffer);
      const status = summary.errors.length > 0 && summary.imported === 0 ? 422 : 200;
      return res.status(status).json(summary);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Excel import failed';
      return res.status(500).json({ error: message });
    }
  },
);

// GE-EXEC-004B-REV3 — Campaign Operations: send the Zalo campaign to
// the selected prospects.
//
// IMPORTANT / NOT independently verifiable in this environment: this
// calls services/zalo-transport.ts, which talks to Zalo's real ZNS
// (Zalo Notification Service) API. It requires ZALO_ZNS_ACCESS_TOKEN
// and ZALO_ZNS_TEMPLATE_ID to be configured, and an approved ZNS
// template on the Zalo side. Without those, every recipient will come
// back as a reported failure rather than silently "succeeding" — see
// zalo-transport.ts for details.
router.post('/prospects/zalo-broadcast', async (req: Request, res: Response) => {
  try {
    const ids = req.body?.ids;
    if (!Array.isArray(ids) || ids.some((id) => typeof id !== 'string') || ids.length === 0) {
      return res.status(400).json({ error: 'Request body must include a non-empty "ids" array of strings.' });
    }
    const prospects = await supabaseDAL.getAllProspects();
    const targets = prospects.filter((p: any) => ids.includes(p.id));
    const result = await sendZaloBroadcast(targets);
    return res.json(result);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Zalo broadcast failed';
    return res.status(500).json({ error: message });
  }
});

export default router;
