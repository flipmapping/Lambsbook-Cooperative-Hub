import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import {
  insertEnquirySchema,
  insertMemberSchema,
  insertPartnerSchema,
  insertCountrySchema,
  insertServiceSchema,
  insertFollowUpSchema,
  insertSiteContentSchema,
  insertIntegrationConfigSchema,
} from "@shared/schema";
import { z } from "zod";
import { generateAIResponse, generateLeadScore } from "./services/ai";
import { notifyNewEnquiry } from "./services/notifications";
import { submitProspectRegistration, listProspects, getProspect, updateProspectStage, recordProspectLifecycleEvent, getProspectLifecycleEvents, recordProspectActivity, getProspectActivities, createProspectFollowupTask, getProspectFollowupTasks, updateProspectFollowupTask, completeProspectFollowupTask, createProspectAppointment, getProspectAppointments, updateProspectAppointment, cancelProspectAppointment, completeProspectAppointment, createProspectDocument, getProspectDocuments, updateProspectDocument, archiveProspectDocument, recordProspectAdmissionDecision, getProspectAdmissionDecisions } from "./services/admissions";
import {
  createClickUpTask,
  createApolloContact,
  integrationGuides,
} from "./services/integrations";
import {
  sendMagicLink,
  sendEmailOTP,
  verifyEmailOTP,
  signUpWithPassword,
  signInWithPassword,
  signOut,
  resetPassword,
  getUser,
} from "./services/supabase-auth";
import adminRoutes from "./routes/admin";
import memberRoutes from "./routes/member";
import financialRoutes from "./routes/financialRoutes";
import governanceRoute from "./routes/governanceRoute";
import devTestAuthRoutes from "./routes/devTestAuth";
import notificationPreferencesRoute from "./routes/notification-preferences.route";
import { detectPlatformAdmin } from "./middleware/requirePlatformAdmin";

import { requireSBURole } from "./middleware/requireSBURole";
import { attachUserContext } from "./middleware/attachUserContext";

import type { AuthenticatedRequest } from "./types/requestContext";
import { createAuthenticatedClient } from "./lib/supabase-member-client";
import { getSupabaseAdmin } from "./lib/supabase-client";
import { supabaseDAL } from "./lib";
export async function registerRoutes(
  httpServer: Server,
  app: Express,
): Promise<Server> {
  app.use(detectPlatformAdmin);
  app.use("/api/admin", adminRoutes);
  app.use("/api/member", memberRoutes);
  app.use("/api/notification-preferences", notificationPreferencesRoute);
  app.use(financialRoutes);
  app.use(governanceRoute);
  app.use("/dev", devTestAuthRoutes);

  app.get("/api/dashboard/stats", async (req: Request, res: Response) => {
    try {
      const stats = await storage.getDashboardStats();
      res.json(stats);
    } catch (error) {
      console.error("Dashboard stats error:", error);
      res.status(500).json({ error: "Failed to fetch dashboard stats" });
    }
  });

  app.get("/api/enquiries", async (req: Request, res: Response) => {
    try {
      const { status, assignedMemberId } = req.query;
      const filters: { status?: string; assignedMemberId?: string } = {};
      if (status) filters.status = status as string;
      if (assignedMemberId)
        filters.assignedMemberId = assignedMemberId as string;

      const enquiriesList = await storage.getEnquiries(filters);
      res.json(enquiriesList);
    } catch (error) {
      console.error("Enquiries error:", error);
      res.status(500).json({ error: "Failed to fetch enquiries" });
    }
  });

  app.get("/api/enquiries/:id", async (req: Request, res: Response) => {
    try {
      const enquiry = await storage.getEnquiry(req.params.id);
      if (!enquiry) {
        return res.status(404).json({ error: "Enquiry not found" });
      }
      res.json(enquiry);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch enquiry" });
    }
  });

  app.post("/api/enquiries", async (req: Request, res: Response) => {
    try {
      const data = insertEnquirySchema.parse(req.body);

      const leadScore = await generateLeadScore({
        inquiryType: data.inquiryType,
        message: data.message ?? undefined,
        countryOfInterest: data.countryOfInterest ?? undefined,
      });

      const enquiry = await storage.createEnquiry({
        ...data,
        leadScore,
      });

      await storage.createActivityLog({
        action: "created",
        entityType: "enquiry",
        entityId: enquiry.id,
        details: { name: enquiry.name, email: enquiry.email },
      });

      notifyNewEnquiry(enquiry.id, {
        name: enquiry.name,
        email: enquiry.email,
        inquiryType: enquiry.inquiryType,
        countryOfInterest: enquiry.countryOfInterest || undefined,
      }).catch((err) => console.error("Notification error:", err));

      createClickUpTask(enquiry.id, {
        name: enquiry.name,
        email: enquiry.email,
        inquiryType: enquiry.inquiryType,
        message: enquiry.message || undefined,
        countryOfInterest: enquiry.countryOfInterest || undefined,
      }).catch((err) => console.error("ClickUp error:", err));

      createApolloContact(enquiry.id, {
        name: enquiry.name,
        email: enquiry.email,
        phone: enquiry.phone || undefined,
      }).catch((err) => console.error("Apollo error:", err));

      res.status(201).json(enquiry);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create enquiry" });
    }
  });

  app.patch("/api/enquiries/:id", async (req: Request, res: Response) => {
    try {
      const enquiry = await storage.updateEnquiry(req.params.id, req.body);
      if (!enquiry) {
        return res.status(404).json({ error: "Enquiry not found" });
      }

      await storage.createActivityLog({
        action: "updated",
        entityType: "enquiry",
        entityId: enquiry.id,
        details: req.body,
      });

      res.json(enquiry);
    } catch (error) {
      res.status(500).json({ error: "Failed to update enquiry" });
    }
  });

  app.get("/api/members", async (req: Request, res: Response) => {
    try {
      const membersList = await storage.getMembers();
      res.json(membersList);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch members" });
    }
  });

  app.get("/api/members/:id", async (req: Request, res: Response) => {
    try {
      const member = await storage.getMember(req.params.id);
      if (!member) {
        return res.status(404).json({ error: "Member not found" });
      }
      res.json(member);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch member" });
    }
  });

  app.post("/api/members", async (req: Request, res: Response) => {
    try {
      const data = insertMemberSchema.parse(req.body);
      const member = await storage.createMember(data);
      res.status(201).json(member);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create member" });
    }
  });

  app.patch("/api/members/:id", async (req: Request, res: Response) => {
    try {
      const member = await storage.updateMember(req.params.id, req.body);
      if (!member) {
        return res.status(404).json({ error: "Member not found" });
      }
      res.json(member);
    } catch (error) {
      res.status(500).json({ error: "Failed to update member" });
    }
  });

  app.get("/api/partners", async (req: Request, res: Response) => {
    try {
      const partnersList = await storage.getPartners();
      res.json(partnersList);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch partners" });
    }
  });

  app.get("/api/partners/:id", async (req: Request, res: Response) => {
    try {
      const partner = await storage.getPartner(req.params.id);
      if (!partner) {
        return res.status(404).json({ error: "Partner not found" });
      }
      res.json(partner);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch partner" });
    }
  });

  app.post("/api/partners", async (req: Request, res: Response) => {
    try {
      const data = insertPartnerSchema.parse(req.body);
      const partner = await storage.createPartner(data);
      res.status(201).json(partner);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create partner" });
    }
  });

  app.patch("/api/partners/:id", async (req: Request, res: Response) => {
    try {
      const partner = await storage.updatePartner(req.params.id, req.body);
      if (!partner) {
        return res.status(404).json({ error: "Partner not found" });
      }
      res.json(partner);
    } catch (error) {
      res.status(500).json({ error: "Failed to update partner" });
    }
  });

  // ============================================================
  // ADMISSIONS ROUTES
  // ============================================================

  app.post("/api/admissions/prospects", async (req: Request, res: Response) => {
    try {
      const prospectSchema = z.object({
        fullName:          z.string().min(1, "Full name is required"),
        email:             z.string().email("Valid email is required"),
        country:           z.string().min(1, "Country is required"),
        programOfInterest: z.string().min(1, "Program of interest is required"),
        phone:             z.string().optional(),
      });

      const data = prospectSchema.parse(req.body);
      const result = await submitProspectRegistration(data);
      res.json(result);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      console.error("Admissions prospect error:", error);
      res.status(500).json({ error: "Failed to process prospect registration" });
    }
  });

  app.get("/api/admissions/prospects", async (req: Request, res: Response) => {
    try {
      const prospects = await listProspects();
      res.json(prospects);
    } catch (error) {
      console.error("List prospects error:", error);
      res.status(500).json({ error: "Failed to list prospects" });
    }
  });

  app.get("/api/admissions/prospects/:id", async (req: Request, res: Response) => {
    try {
      const prospect = await getProspect(req.params.id);
      if (!prospect) {
        return res.status(404).json({ error: "Prospect not found" });
      }
      res.json(prospect);
    } catch (error) {
      console.error("Get prospect error:", error);
      res.status(500).json({ error: "Failed to get prospect" });
    }
  });

  app.patch("/api/admissions/prospects/:id/stage", async (req: Request, res: Response) => {
    try {
      const { current_stage } = req.body;
      if (!current_stage || typeof current_stage !== "string") {
        return res.status(400).json({ error: "current_stage is required" });
      }
      const existingProspect = await getProspect(req.params.id);
      const fromStage = existingProspect?.current_stage ?? null;
      const journey = await updateProspectStage(req.params.id, current_stage);
      if (!journey) {
        return res.status(404).json({ error: "No journey found for this prospect" });
      }
      await recordProspectLifecycleEvent(
        req.params.id,
        fromStage,
        current_stage,
      ).catch((err) => {
        console.error("Lifecycle event record error (non-blocking):", err);
      });
      res.json(journey);
    } catch (error) {
      console.error("Update prospect stage error:", error);
      res.status(500).json({ error: "Failed to update prospect stage" });
    }
  });

  app.get("/api/admissions/prospects/:id/events", async (req: Request, res: Response) => {
    try {
      const events = await getProspectLifecycleEvents(req.params.id);
      res.json(events);
    } catch (error) {
      console.error("List lifecycle events error:", error);
      res.status(500).json({ error: "Failed to list lifecycle events" });
    }
  });

  app.get("/api/admissions/prospects/:id/activities", async (req: Request, res: Response) => {
    try {
      const activities = await getProspectActivities(req.params.id);
      res.json(activities);
    } catch (error) {
      console.error("List prospect activities error:", error);
      res.status(500).json({ error: "Failed to list prospect activities" });
    }
  });

  app.get("/api/admissions/prospects/:id/followup-tasks", async (req: Request, res: Response) => {
    try {
      const tasks = await getProspectFollowupTasks(req.params.id);
      res.json(tasks);
    } catch (error) {
      console.error("List follow-up tasks error:", error);
      res.status(500).json({ error: "Failed to list follow-up tasks" });
    }
  });

  app.post("/api/admissions/prospects/:id/followup-tasks", async (req: Request, res: Response) => {
    try {
      const { title, description, due_date } = req.body;
      if (!title || typeof title !== "string") {
        return res.status(400).json({ error: "title is required" });
      }
      const task = await createProspectFollowupTask(
        req.params.id,
        title,
        description ?? null,
        due_date ?? null,
      );
      res.status(201).json(task);
    } catch (error) {
      console.error("Create follow-up task error:", error);
      res.status(500).json({ error: "Failed to create follow-up task" });
    }
  });

  app.patch("/api/admissions/prospects/:id/followup-tasks/:taskId", async (req: Request, res: Response) => {
    try {
      const { title, description, due_date } = req.body;
      const task = await updateProspectFollowupTask(
        req.params.taskId,
        title,
        description,
        due_date,
      );
      res.json(task);
    } catch (error) {
      console.error("Update follow-up task error:", error);
      res.status(500).json({ error: "Failed to update follow-up task" });
    }
  });

  app.post("/api/admissions/prospects/:id/followup-tasks/:taskId/complete", async (req: Request, res: Response) => {
    try {
      const task = await completeProspectFollowupTask(req.params.taskId);
      res.json(task);
    } catch (error) {
      console.error("Complete follow-up task error:", error);
      res.status(500).json({ error: "Failed to complete follow-up task" });
    }
  });

  app.get("/api/admissions/prospects/:id/appointments", async (req: Request, res: Response) => {
    try {
      const appts = await getProspectAppointments(req.params.id);
      res.json(appts);
    } catch (error) {
      console.error("List appointments error:", error);
      res.status(500).json({ error: "Failed to list appointments" });
    }
  });

  app.post("/api/admissions/prospects/:id/appointments", async (req: Request, res: Response) => {
    try {
      const { title, scheduled_at, duration_minutes, location, notes } = req.body;
      if (!title || typeof title !== "string") {
        return res.status(400).json({ error: "title is required" });
      }
      if (!scheduled_at || typeof scheduled_at !== "string") {
        return res.status(400).json({ error: "scheduled_at is required" });
      }
      const appt = await createProspectAppointment(
        req.params.id, title, scheduled_at,
        duration_minutes ?? null, location ?? null, notes ?? null,
      );
      res.status(201).json(appt);
    } catch (error) {
      console.error("Create appointment error:", error);
      res.status(500).json({ error: "Failed to create appointment" });
    }
  });

  app.patch("/api/admissions/prospects/:id/appointments/:appointmentId", async (req: Request, res: Response) => {
    try {
      const { title, scheduled_at, duration_minutes, location, notes } = req.body;
      const appt = await updateProspectAppointment(
        req.params.appointmentId, title, scheduled_at,
        duration_minutes, location, notes,
      );
      res.json(appt);
    } catch (error) {
      console.error("Update appointment error:", error);
      res.status(500).json({ error: "Failed to update appointment" });
    }
  });

  app.post("/api/admissions/prospects/:id/appointments/:appointmentId/cancel", async (req: Request, res: Response) => {
    try {
      const appt = await cancelProspectAppointment(req.params.appointmentId);
      res.json(appt);
    } catch (error) {
      console.error("Cancel appointment error:", error);
      res.status(500).json({ error: "Failed to cancel appointment" });
    }
  });

  app.post("/api/admissions/prospects/:id/appointments/:appointmentId/complete", async (req: Request, res: Response) => {
    try {
      const { outcome, outcome_notes } = req.body;
      if (!outcome || typeof outcome !== "string") {
        return res.status(400).json({ error: "outcome is required" });
      }
      const appt = await completeProspectAppointment(
        req.params.appointmentId, outcome, outcome_notes ?? null,
      );
      res.json(appt);
    } catch (error) {
      console.error("Complete appointment error:", error);
      res.status(500).json({ error: "Failed to complete appointment" });
    }
  });

  app.get("/api/admissions/prospects/:id/documents", async (req: Request, res: Response) => {
    try {
      const docs = await getProspectDocuments(req.params.id);
      res.json(docs);
    } catch (error) {
      console.error("List documents error:", error);
      res.status(500).json({ error: "Failed to list documents" });
    }
  });

  app.post("/api/admissions/prospects/:id/documents", async (req: Request, res: Response) => {
    try {
      const { document_type, file_name, storage_url, notes } = req.body;
      if (!document_type || typeof document_type !== "string") {
        return res.status(400).json({ error: "document_type is required" });
      }
      if (!file_name || typeof file_name !== "string") {
        return res.status(400).json({ error: "file_name is required" });
      }
      const doc = await createProspectDocument(
        req.params.id, document_type, file_name,
        storage_url ?? null, notes ?? null,
      );
      res.status(201).json(doc);
    } catch (error) {
      console.error("Create document error:", error);
      res.status(500).json({ error: "Failed to create document" });
    }
  });

  app.patch("/api/admissions/prospects/:id/documents/:documentId", async (req: Request, res: Response) => {
    try {
      const { document_type, file_name, storage_url, notes } = req.body;
      const doc = await updateProspectDocument(
        req.params.documentId, document_type, file_name, storage_url, notes,
      );
      res.json(doc);
    } catch (error) {
      console.error("Update document error:", error);
      res.status(500).json({ error: "Failed to update document" });
    }
  });

  app.post("/api/admissions/prospects/:id/documents/:documentId/archive", async (req: Request, res: Response) => {
    try {
      const doc = await archiveProspectDocument(req.params.documentId);
      res.json(doc);
    } catch (error) {
      console.error("Archive document error:", error);
      res.status(500).json({ error: "Failed to archive document" });
    }
  });

  app.get("/api/admissions/prospects/:id/decisions", async (req: Request, res: Response) => {
    try {
      const decisions = await getProspectAdmissionDecisions(req.params.id);
      res.json(decisions);
    } catch (error) {
      console.error("List admission decisions error:", error);
      res.status(500).json({ error: "Failed to list admission decisions" });
    }
  });

  app.post("/api/admissions/prospects/:id/decisions", async (req: Request, res: Response) => {
    try {
      const { decision, rationale, decided_by, offer_ready } = req.body;
      if (!decision || typeof decision !== "string") {
        return res.status(400).json({ error: "decision is required" });
      }
      const dec = await recordProspectAdmissionDecision(
        req.params.id,
        decision,
        rationale ?? null,
        decided_by ?? null,
        offer_ready === true,
      );
      res.status(201).json(dec);
    } catch (error) {
      console.error("Record admission decision error:", error);
      res.status(500).json({ error: "Failed to record admission decision" });
    }
  });

  app.get("/api/countries", async (req: Request, res: Response) => {
    try {
      const countriesList = await storage.getCountries();
      res.json(countriesList);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch countries" });
    }
  });

  app.post("/api/countries", async (req: Request, res: Response) => {
    try {
      const data = insertCountrySchema.parse(req.body);
      const country = await storage.createCountry(data);
      res.status(201).json(country);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create country" });
    }
  });

  app.get("/api/services", async (req: Request, res: Response) => {
    try {
      const servicesList = await storage.getServices();
      res.json(servicesList);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch services" });
    }
  });

  app.post("/api/services", async (req: Request, res: Response) => {
    try {
      const data = insertServiceSchema.parse(req.body);
      const service = await storage.createService(data);
      res.status(201).json(service);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create service" });
    }
  });

  app.get("/api/follow-ups", async (req: Request, res: Response) => {
    try {
      const { enquiryId } = req.query;
      const followUpsList = await storage.getFollowUps(
        enquiryId as string | undefined,
      );
      res.json(followUpsList);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch follow-ups" });
    }
  });

  app.post("/api/follow-ups", async (req: Request, res: Response) => {
    try {
      const data = insertFollowUpSchema.parse(req.body);
      const followUp = await storage.createFollowUp(data);
      res.status(201).json(followUp);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create follow-up" });
    }
  });

  app.patch("/api/follow-ups/:id", async (req: Request, res: Response) => {
    try {
      const followUp = await storage.updateFollowUp(req.params.id, req.body);
      if (!followUp) {
        return res.status(404).json({ error: "Follow-up not found" });
      }
      res.json(followUp);
    } catch (error) {
      res.status(500).json({ error: "Failed to update follow-up" });
    }
  });

  app.get("/api/notifications", async (req: Request, res: Response) => {
    try {
      const { recipientId } = req.query;
      const notificationsList = await storage.getNotifications(
        recipientId as string | undefined,
      );
      res.json(notificationsList);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch notifications" });
    }
  });

  app.get("/api/site-content", async (req: Request, res: Response) => {
    try {
      const { section } = req.query;
      const contentList = await storage.getSiteContent(
        section as string | undefined,
      );
      res.json(contentList);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch site content" });
    }
  });

  app.get("/api/site-content/:key", async (req: Request, res: Response) => {
    try {
      const content = await storage.getSiteContentByKey(req.params.key);
      if (!content) {
        return res.status(404).json({ error: "Content not found" });
      }
      res.json(content);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch site content" });
    }
  });

  app.put("/api/site-content", async (req: Request, res: Response) => {
    try {
      const data = insertSiteContentSchema.parse(req.body);
      const content = await storage.upsertSiteContent(data);
      res.json(content);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to save site content" });
    }
  });

  app.get("/api/integrations", async (req: Request, res: Response) => {
    try {
      const configs = await storage.getIntegrationConfigs();
      res.json(configs);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch integration configs" });
    }
  });

  app.get("/api/integrations/:service", async (req: Request, res: Response) => {
    try {
      const config = await storage.getIntegrationConfig(req.params.service);
      if (!config) {
        return res.status(404).json({ error: "Integration config not found" });
      }
      res.json(config);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch integration config" });
    }
  });

  app.put("/api/integrations", async (req: Request, res: Response) => {
    try {
      const data = insertIntegrationConfigSchema.parse(req.body);
      const config = await storage.upsertIntegrationConfig(data);
      res.json(config);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to save integration config" });
    }
  });

  app.get("/api/activity-logs", async (req: Request, res: Response) => {
    try {
      const { entityType, entityId } = req.query;
      const logs = await storage.getActivityLogs(
        entityType as string | undefined,
        entityId as string | undefined,
      );
      res.json(logs);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch activity logs" });
    }
  });

  app.post("/api/seed-data", async (req: Request, res: Response) => {
    try {
      const existingCountries = await storage.getCountries();
      if (existingCountries.length === 0) {
        const defaultCountries = [
          { code: "USA", name: "United States", flag: "us" },
          { code: "CAN", name: "Canada", flag: "ca" },
          { code: "GBR", name: "United Kingdom", flag: "gb" },
          { code: "AUS", name: "Australia", flag: "au" },
          { code: "VNM", name: "Vietnam", flag: "vn" },
          { code: "MYS", name: "Malaysia", flag: "my" },
          { code: "TWN", name: "Taiwan", flag: "tw" },
          { code: "CHN", name: "China", flag: "cn" },
        ];

        for (const country of defaultCountries) {
          await storage.createCountry(country);
        }
      }

      const existingServices = await storage.getServices();
      if (existingServices.length === 0) {
        const defaultServices = [
          {
            code: "EB3A",
            name: "EB-3A Professionals",
            category: "work_visa",
            description: "For professionals with bachelor's degree",
          },
          {
            code: "EB3B",
            name: "EB-3B Skilled Workers",
            category: "work_visa",
            description: "For skilled workers with 2+ years experience",
          },
          {
            code: "EB3C",
            name: "EB-3C Other Workers",
            category: "work_visa",
            description: "For unskilled workers",
          },
          {
            code: "STUDY",
            name: "Study Abroad",
            category: "education",
            description: "University admission and student visa support",
          },
          {
            code: "SCHOLAR",
            name: "Scholarship Applications",
            category: "education",
            description: "Help securing financial aid",
          },
          {
            code: "TOURIST",
            name: "Tourist Visa",
            category: "visa",
            description: "Tourist and travel visa processing",
          },
          {
            code: "BUSINESS",
            name: "Business Visa",
            category: "visa",
            description: "Business visa processing",
          },
          {
            code: "JOB",
            name: "Job Placement",
            category: "employment",
            description: "Connect with employers",
          },
        ];

        for (const service of defaultServices) {
          await storage.createService(service);
        }
      }

      res.json({ success: true, message: "Seed data created successfully" });
    } catch (error) {
      res.status(500).json({ error: "Failed to seed data" });
    }
  });

  app.post("/api/ai/chat", async (req: Request, res: Response) => {
    try {
      const { message, conversationHistory, sessionId } = req.body;

      if (!message || typeof message !== "string") {
        return res.status(400).json({ error: "Message is required" });
      }

      const result = await generateAIResponse(
        message,
        conversationHistory || [],
      );

      if (sessionId) {
        await storage.createAIChatLog({
          sessionId,
          userMessage: message,
          aiResponse: result.response,
          intent: result.intent,
          sentiment: result.sentiment,
        });
      }

      res.json(result);
    } catch (error) {
      console.error("AI chat error:", error);
      res.status(500).json({ error: "Failed to generate AI response" });
    }
  });

  app.get("/api/ai/chat-logs", async (req: Request, res: Response) => {
    try {
      const { sessionId } = req.query;
      const logs = await storage.getAIChatLogs(sessionId as string | undefined);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch chat logs" });
    }
  });

  app.get("/api/integration-guides", async (req: Request, res: Response) => {
    res.json(integrationGuides);
  });

  // ============================================================
  // AUTHENTICATION ROUTES (Supabase Auth with Email 2FA)
  // ============================================================

  // Send magic link for passwordless login
  app.post("/api/auth/magic-link", async (req: Request, res: Response) => {
    try {
      const { email } = req.body;
      if (!email || typeof email !== "string") {
        return res.status(400).json({ error: "Email is required" });
      }
      const result = await sendMagicLink(email);
      res.json(result);
    } catch (error) {
      console.error("Magic link error:", error);
      res.status(500).json({ error: "Failed to send magic link" });
    }
  });

  // Send email OTP for 2FA
  app.post("/api/auth/send-otp", async (req: Request, res: Response) => {
    try {
      const { email } = req.body;
      if (!email || typeof email !== "string") {
        return res.status(400).json({ error: "Email is required" });
      }
      const result = await sendEmailOTP(email);
      res.json(result);
    } catch (error) {
      console.error("Send OTP error:", error);
      res.status(500).json({ error: "Failed to send OTP" });
    }
  });

  // Verify email OTP
  app.post("/api/auth/verify-otp", async (req: Request, res: Response) => {
    try {
      const { email, token } = req.body;
      if (!email || !token) {
        return res.status(400).json({ error: "Email and token are required" });
      }
      const result = await verifyEmailOTP(email, token);
      res.json(result);
    } catch (error) {
      console.error("Verify OTP error:", error);
      res.status(500).json({ error: "Failed to verify OTP" });
    }
  });

  // Sign up with email and password
  app.post("/api/auth/signup", async (req: Request, res: Response) => {
    try {
      const { email, password, fullName, role } = req.body;
      if (!email || !password) {
        return res
          .status(400)
          .json({ error: "Email and password are required" });
      }
      const result = await signUpWithPassword(email, password, {
        full_name: fullName,
        role: role || "member",
      });
      res.json(result);
    } catch (error) {
      console.error("Signup error:", error);
      res.status(500).json({ error: "Failed to sign up" });
    }
  });

  // Sign in with email and password
  app.post("/api/auth/signin", async (req: Request, res: Response) => {
    try {
      const { email, password } = req.body;
      if (!email || !password) {
        return res
          .status(400)
          .json({ error: "Email and password are required" });
      }
      const result = await signInWithPassword(email, password);
      res.json(result);
    } catch (error) {
      console.error("Signin error:", error);
      res.status(500).json({ error: "Failed to sign in" });
    }
  });

  // Sign out
  app.post("/api/auth/signout", async (req: Request, res: Response) => {
    try {
      const result = await signOut();
      res.json(result);
    } catch (error) {
      console.error("Signout error:", error);
      res.status(500).json({ error: "Failed to sign out" });
    }
  });

  // Reset password
  app.post("/api/auth/reset-password", async (req: Request, res: Response) => {
    try {
      const { email } = req.body;
      if (!email) {
        return res.status(400).json({ error: "Email is required" });
      }
      const result = await resetPassword(email);
      res.json(result);
    } catch (error) {
      console.error("Reset password error:", error);
      res.status(500).json({ error: "Failed to reset password" });
    }
  });

  // Get current user (requires auth token)
  app.get("/api/auth/me", async (req: Request, res: Response) => {
    try {
      const authHeader = req.headers.authorization;
      if (!authHeader || !authHeader.startsWith("Bearer ")) {
        return res
          .status(401)
          .json({ error: "No authorization token provided" });
      }
      const token = authHeader.split(" ")[1];
      const result = await getUser(token);
      res.json(result);
    } catch (error) {
      console.error("Get user error:", error);
      res.status(500).json({ error: "Failed to get user" });
    }
  });

  // ========================================
  // Lambsbook Agentic Hub API Routes (Supabase)
  // Note: These routes use a separate Supabase database for the Hub system
  // which is distinct from the local PostgreSQL used for enquiries/members.
  // ========================================

  const hubService = await import("./services/supabase-hub");

  // SBUs
  app.get("/api/hub/sbus", async (req: Request, res: Response) => {
    try {
      const sbus = await hubService.getSBUs();
      res.json(sbus);
    } catch (error) {
      console.error("SBUs error:", error);
      res.status(500).json({ error: "Failed to fetch SBUs" });
    }
  });

  app.patch("/api/hub/sbus/:id", async (req: Request, res: Response) => {
    try {
      const validatedData = hubService.updateSBUSchema.parse(req.body);
      const sbu = await hubService.updateSBU(req.params.id, validatedData);
      res.json(sbu);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      console.error("Update SBU error:", error);
      res.status(500).json({ error: "Failed to update SBU" });
    }
  });

  // Programs
  app.get("/api/hub/programs", async (req: Request, res: Response) => {
    try {
      const programs = await hubService.getPrograms();
      res.json(programs);
    } catch (error) {
      console.error("Programs error:", error);
      res.status(500).json({ error: "Failed to fetch programs" });
    }
  });

  app.post("/api/hub/programs", async (req: Request, res: Response) => {
    try {
      const validatedData = hubService.insertProgramSchema.parse(req.body);
      const program = await hubService.createProgram(validatedData);
      res.status(201).json(program);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      console.error("Create program error:", error);
      res.status(500).json({ error: "Failed to create program" });
    }
  });

  app.patch("/api/hub/programs/:id", async (req: Request, res: Response) => {
    try {
      const validatedData = hubService.updateProgramSchema.parse(req.body);
      const program = await hubService.updateProgram(
        req.params.id,
        validatedData,
      );
      res.json(program);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      console.error("Update program error:", error);
      res.status(500).json({ error: "Failed to update program" });
    }
  });

  // Commission Rule Sets
  app.get(
    "/api/hub/commission-rule-sets",
    async (req: Request, res: Response) => {
      try {
        const ruleSets = await hubService.getCommissionRuleSets();
        res.json(ruleSets);
      } catch (error) {
        console.error("Commission rule sets error:", error);
        res.status(500).json({ error: "Failed to fetch commission rule sets" });
      }
    },
  );

  app.post(
    "/api/hub/commission-rule-sets",
    async (req: Request, res: Response) => {
      try {
        const validatedData = hubService.insertCommissionRuleSetSchema.parse(
          req.body,
        );
        const ruleSet = await hubService.createCommissionRuleSet(validatedData);
        res.status(201).json(ruleSet);
      } catch (error) {
        if (error instanceof z.ZodError) {
          return res.status(400).json({ error: error.errors });
        }
        console.error("Create commission rule set error:", error);
        res.status(500).json({ error: "Failed to create commission rule set" });
      }
    },
  );

  // Commission Rules
  app.post("/api/hub/commission-rules", async (req: Request, res: Response) => {
    try {
      const validatedData = hubService.insertCommissionRuleSchema.parse(
        req.body,
      );
      const rule = await hubService.createCommissionRule(validatedData);
      res.status(201).json(rule);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      console.error("Create commission rule error:", error);
      res.status(500).json({ error: "Failed to create commission rule" });
    }
  });

  app.delete(
    "/api/hub/commission-rules/:id",
    async (req: Request, res: Response) => {
      try {
        const idSchema = z.string().uuid();
        idSchema.parse(req.params.id);
        await hubService.deleteCommissionRule(req.params.id);
        res.json({ success: true });
      } catch (error) {
        if (error instanceof z.ZodError) {
          return res.status(400).json({ error: "Invalid rule ID" });
        }
        console.error("Delete commission rule error:", error);
        res.status(500).json({ error: "Failed to delete commission rule" });
      }
    },
  );

  // Hub Members
  app.get("/api/hub/members", async (req: Request, res: Response) => {
    try {
      const members = await hubService.getHubMembers();
      res.json(members);
    } catch (error) {
      console.error("Hub members error:", error);
      res.status(500).json({ error: "Failed to fetch hub members" });
    }
  });

  // Transactions
  app.get("/api/hub/transactions", async (req: Request, res: Response) => {
    try {
      const transactions = await hubService.getTransactions();
      res.json(transactions);
    } catch (error) {
      console.error("Transactions error:", error);
      res.status(500).json({ error: "Failed to fetch transactions" });
    }
  });

  // Earnings
  app.get("/api/hub/earnings", async (req: Request, res: Response) => {
    try {
      const earnings = await hubService.getEarnings();
      res.json(earnings);
    } catch (error) {
      console.error("Earnings error:", error);
      res.status(500).json({ error: "Failed to fetch earnings" });
    }
  });

  // ========================================
  // Hub Authentication Routes
  // ========================================

  const hubAuthSchema = z.object({
    email: z.string().email(),
    password: z.string().min(8, "Password must be at least 8 characters").optional(),
    fullName: z.string().min(1).max(255).optional(),
    username: z
      .string()
      .regex(
        /^[a-zA-Z0-9_-]{3,50}$/,
        "Username must be 3-50 characters: letters, numbers, underscores, hyphens",
      )
      .optional(),
    phone: z
      .string()
      .regex(
        /^\+?[0-9]{7,15}$/,
        "Phone must be 7-15 digits with optional + prefix",
      )
      .optional(),
    referrerEmail: z.string().email().optional().or(z.literal("")),
    inviteToken: z.string().optional(),
  });

  app.post("/api/hub/auth/signup", async (req: Request, res: Response) => {
    try {
      // Clean up empty referrerEmail
      const body = { ...req.body };
      if (body.referrerEmail === "") {
        delete body.referrerEmail;
      }

      const validatedData = hubAuthSchema.parse(body);
      const result = await hubService.signUpMember(validatedData);
      res.status(201).json(result);
    } catch (error) {
      if (error instanceof z.ZodError) {
        console.error("Hub signup validation error:", error.errors);
        return res.status(400).json({ error: error.errors });
      }
      // Handle HubAuthError with proper status code
      if (
        error &&
        typeof error === "object" &&
        "name" in error &&
        error.name === "HubAuthError"
      ) {
        const hubError = error as unknown as {
          message: string;
          statusCode: number;
        };
        return res
          .status(hubError.statusCode)
          .json({ error: hubError.message });
      }
      console.error("Hub signup error:", error);
      res.status(500).json({ error: "Failed to send magic link" });
    }
  });

  // Link referrer to member after successful authentication
  app.post(
    "/api/hub/auth/link-referrer",
    async (req: Request, res: Response) => {
      try {
        const { memberEmail, referrerEmail } = req.body;

        if (!memberEmail || !referrerEmail) {
          return res
            .status(400)
            .json({ error: "Both memberEmail and referrerEmail are required" });
        }

        const result = await hubService.linkReferrer(
          memberEmail,
          referrerEmail,
        );

        if (!result.success) {
          return res.status(400).json({ error: result.error });
        }

        res.json(result);
      } catch (error) {
        console.error("Link referrer error:", error);
        res.status(500).json({ error: "Failed to link referrer" });
      }
    },
  );

  // Validate referrer email exists
  app.get(
    "/api/hub/auth/validate-referrer",
    async (req: Request, res: Response) => {
      try {
        const email = req.query.email as string;
        if (!email) {
          return res.status(400).json({ error: "Email is required" });
        }

        const member = await hubService.getMemberByEmail(email);
        res.json({
          valid: !!member,
          member: member
            ? { email: member.email, name: member.full_name }
            : null,
        });
      } catch (error) {
        console.error("Validate referrer error:", error);
        res.status(500).json({ error: "Failed to validate referrer" });
      }
    },
  );

  
  app.post("/api/hub/auth/login", async (req: Request, res: Response) => {
    try {
      const validatedData = hubAuthSchema.parse(req.body);
      const result = await hubService.loginMember(validatedData.email, validatedData.password);
      res.json(result);
    } catch (error) {
      if (error instanceof z.ZodError) {
        console.error("Hub login validation error:", error.errors);
        return res.status(400).json({ error: error.errors });
      }
      if (
        error &&
        typeof error === "object" &&
        "name" in error &&
        error.name === "HubAuthError"
      ) {
        const hubError = error as unknown as {
            message: string;
            statusCode: number;
          };
        return res
          .status(hubError.statusCode)
          .json({ error: hubError.message });
      }
      console.error("Hub login error:", error);
      res.status(500).json({ error: "Login failed" });
    }
  });

app.post("/api/hub/auth/forgot-password", async (req: Request, res: Response) => {
    try {
      const { email } = req.body;
      if (!email) {
        return res.status(400).json({ error: "Email is required" });
      }
      const result = await hubService.forgotPassword(email);
      res.json(result);
    } catch (error) {
      if (
        error &&
        typeof error === "object" &&
        "name" in error &&
        error.name === "HubAuthError"
      ) {
        const hubError = error as unknown as {
          message: string;
          statusCode: number;
        };
        return res
          .status(hubError.statusCode)
          .json({ error: hubError.message });
      }
      console.error("Forgot password error:", error);
      res.status(500).json({ error: "Failed to send password reset email" });
    }
  });

  app.post("/api/hub/auth/reset-password", async (req: Request, res: Response) => {
    try {
      const { accessToken, newPassword } = req.body;
      if (!accessToken || !newPassword) {
        return res.status(400).json({ error: "Access token and new password are required" });
      }
      if (newPassword.length < 8) {
        return res.status(400).json({ error: "Password must be at least 8 characters" });
      }
      const result = await hubService.resetPassword(accessToken, newPassword);
      res.json(result);
    } catch (error) {
      if (
        error &&
        typeof error === "object" &&
        "name" in error &&
        error.name === "HubAuthError"
      ) {
        const hubError = error as unknown as {
          message: string;
          statusCode: number;
        };
        return res
          .status(hubError.statusCode)
          .json({ error: hubError.message });
      }
      console.error("Reset password error:", error);
      res.status(500).json({ error: "Failed to reset password" });
    }
  });

  app.post("/api/hub/auth/logout", async (req: Request, res: Response) => {
    try {
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to logout" });
    }
  });
  // step 1
  // --------------------------------------------------
  // Get pending invitation for current user
  // --------------------------------------------------

  /* residual embedded hub member bridge removed during runtime convergence cleanup */

  /*
  PHASE 1 CONTAINMENT — HUB MEMBER ROUTES DISABLED

  app.post("/api/hub/member/accept-invitation", attachUserContext, async (req: Request, res: Response) => {
    try {
      const authReq = req as AuthenticatedRequest;
      const user = authReq.user;
      const { invitationId } = req.body;

      if (!user?.id) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      if (!invitationId) {
        return res.status(400).json({ message: "Missing invitationId" });
      }

      const supabaseAdmin = getSupabaseAdmin();

      // BIND INVITATION TO CURRENT USER (REQUIRED BEFORE RPC)
      const supabaseUser = createAuthenticatedClient(user.token);
      const { data: userEmail, error: emailError } = await supabaseUser.rpc("get_my_auth_email");

      if (emailError || !userEmail) {
        return res.status(401).json({ message: "User email not found" });
      }

      const { data: bindData, error: bindError } = await supabaseAdmin
        .from("member_invitations")
        .update({ invited_user_id: user.id })
        .eq("id", invitationId)
        .is("invited_user_id", null)
        .eq("invited_email", userEmail)
        .select("id")
        .maybeSingle();

      if (bindError) {
        console.error("[accept-invitation] bind error:", bindError);
        return res.status(500).json({ message: "Failed to bind invitation" });
      }

      // SECURITY CHECK — ensure invitation belongs to this user
      const { data: invitation, error: fetchError } = await supabaseAdmin
        .from("member_invitations")
        .select("id, invited_user_id, status")
        .eq("id", invitationId)
        .maybeSingle();

      if (fetchError || !invitation) {
        return res.status(404).json({ message: "Invitation not found" });
      }

      if (invitation.status !== "pending") {
        return res.status(400).json({ message: "Invitation already processed" });
      }

      // Call database function
      const { error: rpcError } = await supabaseUser.rpc(
        "accept_member_invitation",
        { p_invitation_id: invitationId }
      );

      if (rpcError) {
        console.error('[accept-invitation] RPC error:', rpcError.code, rpcError.message);

        const msg = (rpcError.message ?? '').toLowerCase();

        // 1. AUTHORIZATION FIRST (CRITICAL — PREVENT INFORMATION LEAK)
        if (
          rpcError.code === '42501' ||
          msg.includes('not authorized') ||
          msg.includes('not your invitation') ||
          msg.includes('permission denied')
        ) {
          return res.status(403).json({
            error: {
              code: 'NOT_ALLOWED',
              message: 'You are not authorized to accept this invitation.'
            }
          });
        }

        // 2. NOT FOUND
        if (
          msg.includes('not found') ||
          msg.includes('does not exist') ||
          msg.includes('no invitation')
        ) {
          return res.status(404).json({
            error: {
              code: 'INVITATION_NOT_FOUND',
              message: 'Invitation not found.'
            }
          });
        }

        // 3. STATE (ONLY AFTER AUTHORIZATION PASSES)
        if (
          rpcError.code === '23514' ||
          msg.includes('already accepted') ||
          msg.includes('already processed') ||
          msg.includes('not pending') ||
          msg.includes('expired')
        ) {
          return res.status(409).json({
            error: {
              code: 'INVITATION_ALREADY_PROCESSED',
              message: 'This invitation has already been accepted or is no longer valid.'
            }
          });
        }

        // 4. FALLBACK (NO RAW POSTGRES LEAK)
        return res.status(500).json({
          error: {
            code: 'INTERNAL_ERROR',
            message: 'Failed to accept invitation.'
          }
        });
      }

      return res.json({ success: true });

    } catch (err) {
      console.error(err);
      return res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Server error.' } });
    }
  });

  // --------------------------------------------------
  // Issue invitation
  // --------------------------------------------------
  app.post("/api/hub/member/issue-invitation", attachUserContext, async (req: Request, res: Response) => {
    try {
      const authReq = req as AuthenticatedRequest;
      const user = authReq.user;
      const { invitedUserId } = req.body;

      if (!user?.id) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      if (!invitedUserId) {
        return res.status(400).json({ message: "Missing invitedUserId" });
      }

      const supabaseAdmin = getSupabaseAdmin();

      const { error } = await supabaseAdmin.rpc(
        "issue_member_invitation",
        { p_invited_user_id: invitedUserId }
      );

      if (error) {
        console.error(error);
        return res.status(500).json({ message: error.message });
      }

      return res.json({ success: true });

    } catch (err) {
      console.error(err);
      return res.status(500).json({ message: "Server error" });
    }
  });

  // Member self-service endpoints
  app.get("/api/hub/member/me", attachUserContext, async (req: Request, res: Response) => {
    try {
      const authReq = req as AuthenticatedRequest;
      const user = authReq.user;
      if (!user) {
        return res.status(401).json({ error: "Unauthorized" });
      }

      const supabase = createAuthenticatedClient(user.token);
      const { data: userEmail, error: userEmailError } = await supabase.rpc("get_my_auth_email");

      if (userEmailError || !userEmail) {
        return res.status(401).json({ error: "User email not found" });
      }

      // Fetch member data from Supabase
      const member = await hubService.getMemberByEmail(userEmail);

      if (member) {
        // Return real member data from Supabase
        res.json({
          id: member.id,
          email: member.email,
          full_name: member.full_name || userEmail.split("@")[0],
          referral_code: member.id.slice(0, 8).toUpperCase(),
          roles: ["user", "collaborator"],
          total_earnings: 0, // Will be calculated from earnings table
          pending_earnings: 0,
          referral_count: 0,
          programs_enrolled: 0,
        });
      } else {
        // User is authenticated but not yet in members table - return basic info
        res.json({
          id: user.id,
          email: userEmail,
          full_name: userEmail.split("@")[0],
          referral_code: user.id.slice(0, 8).toUpperCase(),
          roles: ["user"],
          total_earnings: 0,
          pending_earnings: 0,
          referral_count: 0,
          programs_enrolled: 0,
        });
      }
    } catch (error) {
      console.error("Get member error:", error);
      res.status(500).json({ error: "Failed to get member data" });
    }
  });

  app.get("/api/hub/member/earnings", attachUserContext, async (req: Request, res: Response) => {
    try {
      const authReq = req as AuthenticatedRequest;
      const user = authReq.user;

      if (!user?.id) {
        return res.status(401).json({ error: "Unauthorized" });
      }

      const member = await supabaseDAL.getMemberByUserId(user.id);

      if (!member) {
        return res.json([]);
      }

      const earnings =
        await supabaseDAL.getEarningsByMember(member.id);

      return res.json(earnings);
    } catch (error) {
      console.error("Get earnings error:", error);
      res.status(500).json({ error: "Failed to get earnings" });
    }
  });

  app.get("/api/hub/member/invitees", attachUserContext, async (req: Request, res: Response) => {
    try {
      const authReq = req as AuthenticatedRequest;

      // Return empty array for now - will fetch from Supabase collaborations table in future
      res.json([]);
    } catch (error) {
      console.error("Get invitees error:", error);
      res.status(500).json({ error: "Failed to get invitees" });
    }
  });

  app.get("/api/hub/member/invitor", attachUserContext, async (req: Request, res: Response) => {
    try {
      const authReq = req as AuthenticatedRequest;

      // Return null for now - will fetch from Supabase members.invitor_id in future
      res.json(null);
    } catch (error) {
      console.error("Get invitor error:", error);
      res.status(500).json({ error: "Failed to get invitor" });
    }
  });

  app.get("/api/hub/member/referrals", attachUserContext, async (req: Request, res: Response) => {
    try {
      const authReq = req as AuthenticatedRequest;

      // Return empty array for now - will fetch from Supabase in future
      res.json([]);
    } catch (error) {
      console.error("Get referrals error:", error);
      res.status(500).json({ error: "Failed to get referrals" });
    }
  });


  */

  // ========================================
  // Hub Partner & Revenue Sharing Routes
  // ========================================

  const hubPartnerService = await import("./services/hub-partners");

  // Get all hub partners (optionally filter by SBU)
  app.get("/api/hub/partners", async (req: Request, res: Response) => {
    try {
      const sbuId = req.query.sbuId as string | undefined;
      const partners = await hubPartnerService.getHubPartners(sbuId);
      res.json(partners);
    } catch (error) {
      console.error("Get hub partners error:", error);
      res.status(500).json({ error: "Failed to get partners" });
    }
  });

  // Create a new hub partner (onboarding)
  app.post("/api/hub/partners", async (req: Request, res: Response) => {
    try {
      const { sbuId, roles, company, name, email, phone, capabilities, notes } =
        req.body;

      // Basic validation
      if (!sbuId || !name || !email) {
        return res.status(400).json({
          error: "Missing required fields: sbuId, name, and email are required",
        });
      }

      if (!roles || !Array.isArray(roles) || roles.length === 0) {
        return res.status(400).json({ error: "At least one role is required" });
      }

      const partner = await hubPartnerService.createHubPartner({
        sbuId,
        roles,
        company: company || name, // Use name as company if not provided
        name,
        email,
        phone: phone || null,
        capabilities: capabilities || null,
        notes: notes || null,
        status: "pending",
      });
      res.status(201).json(partner);
    } catch (error) {
      console.error("Create hub partner error:", error);
      res.status(500).json({ error: "Failed to create partner" });
    }
  });

  // Update a hub partner
  app.patch("/api/hub/partners/:id", async (req: Request, res: Response) => {
    try {
      const partner = await hubPartnerService.updateHubPartner(
        req.params.id,
        req.body,
      );
      if (!partner) {
        return res.status(404).json({ error: "Partner not found" });
      }
      res.json(partner);
    } catch (error) {
      console.error("Update hub partner error:", error);
      res.status(500).json({ error: "Failed to update partner" });
    }
  });

  // Get all hub products (optionally filter by SBU)
  app.get("/api/hub/products", async (req: Request, res: Response) => {
    try {
      const sbuId = req.query.sbuId as string | undefined;
      const products = await hubPartnerService.getHubProducts(sbuId);
      res.json(products);
    } catch (error) {
      console.error("Get hub products error:", error);
      res.status(500).json({ error: "Failed to get products" });
    }
  });

  // Get a product with its share allocations
  app.get(
    "/api/hub/products/:id/allocations",
    async (req: Request, res: Response) => {
      try {
        const result = await hubPartnerService.getProductWithAllocations(
          req.params.id,
        );
        if (!result) {
          return res.status(404).json({ error: "Product not found" });
        }
        res.json(result);
      } catch (error) {
        console.error("Get product allocations error:", error);
        res.status(500).json({ error: "Failed to get product allocations" });
      }
    },
  );

  // Update share allocations for a product (with 100% validation)
  app.put(
    "/api/hub/products/:id/allocations",
    async (req: Request, res: Response) => {
      try {
        const result = await hubPartnerService.updateShareAllocations(
          req.params.id,
          req.body.allocations,
        );
        if (!result.success) {
          return res.status(400).json({ error: result.error });
        }
        res.json(result);
      } catch (error) {
        console.error("Update share allocations error:", error);
        res.status(500).json({ error: "Failed to update share allocations" });
      }
    },
  );

  // Get value chain summary for an SBU
  app.get(
    "/api/hub/value-chain/:sbuId",
    async (req: Request, res: Response) => {
      try {
        const summary = await hubPartnerService.getValueChainSummary(
          req.params.sbuId,
        );
        res.json(summary);
      } catch (error) {
        console.error("Get value chain error:", error);
        res.status(500).json({ error: "Failed to get value chain" });
      }
    },
  );

  // Get available value chain roles
  app.get("/api/hub/value-chain-roles", async (req: Request, res: Response) => {
    try {
      const roles = hubPartnerService.getValueChainRoles();
      res.json(roles);
    } catch (error) {
      console.error("Get value chain roles error:", error);
      res.status(500).json({ error: "Failed to get value chain roles" });
    }
  });

  // ========================================
  // Education Feedback Agent Routes
  // ========================================

  const educationFeedbackService = await import(
    "./services/education-feedback"
  );

  // List all documents in the Master Templates folder
  app.get("/api/education/documents", async (req: Request, res: Response) => {
    try {
      const documents = await educationFeedbackService.listMasterTemplates();
      res.json(documents);
    } catch (error) {
      console.error("List documents error:", error);
      res.status(500).json({
        error:
          error instanceof Error ? error.message : "Failed to list documents",
      });
    }
  });

  // Get document preview with validation status
  app.get(
    "/api/education/documents/:id/preview",
    async (req: Request, res: Response) => {
      try {
        const preview = await educationFeedbackService.getDocumentPreview(
          req.params.id,
        );
        res.json(preview);
      } catch (error) {
        console.error("Document preview error:", error);
        res.status(500).json({
          error:
            error instanceof Error
              ? error.message
              : "Failed to get document preview",
        });
      }
    },
  );

  // Generate feedback for a specific document
  app.post(
    "/api/education/documents/:id/feedback",
    async (req: Request, res: Response) => {
      try {
        const result =
          await educationFeedbackService.generateFeedbackForDocument(
            req.params.id,
          );
        res.json(result);
      } catch (error) {
        console.error("Generate feedback error:", error);
        res.status(500).json({
          error:
            error instanceof Error
              ? error.message
              : "Failed to generate feedback",
        });
      }
    },
  );

  // Process all pending documents
  app.post(
    "/api/education/process-all",
    async (req: Request, res: Response) => {
      try {
        const results =
          await educationFeedbackService.processAllPendingDocuments();
        res.json({
          total: results.length,
          successful: results.filter((r) => r.success).length,
          failed: results.filter((r) => !r.success).length,
          results,
        });
      } catch (error) {
        console.error("Process all documents error:", error);
        res.status(500).json({
          error:
            error instanceof Error
              ? error.message
              : "Failed to process documents",
        });
      }
    },
  );

  // Check folder connection status
  app.get("/api/education/status", async (req: Request, res: Response) => {
    try {
      const folderId =
        await educationFeedbackService.findMasterTemplatesFolder();
      res.json({
        connected: !!folderId,
        folderId,
        folderName: "Lambsbook – Master Templates",
      });
    } catch (error) {
      console.error("Check status error:", error);
      res.status(500).json({
        connected: false,
        error:
          error instanceof Error
            ? error.message
            : "Failed to check folder status",
      });
    }
  });

  // Generate feedback from transcript submission (MVP UI endpoint)
  // This route acts as a thin adapter to the Education Feedback Engine
  app.post(
    "/api/education/generate-feedback",
    async (req: Request, res: Response) => {
      try {
        // Call the Education Feedback Engine service
        const result =
          await educationFeedbackService.generateFeedbackFromTranscript({
            task_prompt: req.body.task_prompt,
            transcript_text: req.body.transcript_text,
            youtube_url: req.body.youtube_url,
            assessment_framework: req.body.assessment_framework,
            skill_type: req.body.skill_type,
            speaking_part: req.body.speaking_part,
            current_level: req.body.current_level,
            target_level: req.body.target_level,
          });

        // Return the result from the engine
        if (result.status === "error") {
          return res.status(400).json(result);
        }

        res.json(result);
      } catch (error) {
        console.error("Generate feedback error:", error);
        res.status(500).json({
          status: "error",
          error:
            error instanceof Error
              ? error.message
              : "Failed to generate feedback",
        });
      }
    },
  );

  return httpServer;
}
