# Claude Package

Implementation Authority

MAIN_APP

Repository

Main Application / Execution Runtime Repository (APP-RUNTIME-01)

Authority Stream

—

Production Surface

client/src/pages/MemberHub.tsx

--------------------------------------------------

Package Is the Contract (PIC)

This package is the complete implementation contract.

Claude SHALL consume this package as the sole authoritative implementation contract.

Execution SHALL synchronize using the governance artifacts contained within this package.

--------------------------------------------------

Package Generated

2026-08-28 06:12 UTC

--------------------------------------------------

Execution

Synchronize all governance artifacts in this package before proceeding.

Begin with the Claude Instruction Brief in governance/cib/generated/.
