# APP-MEMBER-DASH-001 — CLAUDE EXECUTION BRIEF

## Authority

MAIN_APP

## Task

APP-MEMBER-DASH-001

## Cycle

2

## Repository

Main Application / Execution Runtime Repository (APP-RUNTIME-01)

## Production Surface

client/src/pages/MemberHub.tsx

## Execution Contract

The generated PIC package is the sole authoritative implementation contract.

Read `START-HERE.md` first, then synchronize the governance artifacts
contained in this package.

Do not infer implementation intent from stale packages or conversational
context.

## Implementation Rule

Follow the supplied CIB and Implementation Authority exactly.

Perform only evidence-backed, in-scope mutations permitted by the frozen
contract.

Stop on any authoritative contradiction, protected-surface collision,
concurrent-WIP collision, backend mutation requirement, missing contract,
authentication/session issue, schema/RLS issue, financial architecture
issue, Organization Studio issue, APP-REC-029R1 reopening, or scope expansion.

## Final Boundary

Do not commit.
Do not push.
Do not deploy.

Return the explicit completion evidence required by the CIB.
