# APP-MEMBER-DASH-001 — PIC Package Reading Guide

## Purpose

This package is the generated implementation contract for APP-MEMBER-DASH-001.

The package is generated from the authoritative Cycle-2 CIB and
Implementation Authority for the MAIN_APP execution stream.

Claude must consume the package as the sole authoritative implementation
contract and must not infer implementation intent from conversational
context.

## Authority

MAIN_APP

## Repository

Main Application / Execution Runtime Repository (APP-RUNTIME-01)

## Production Surface

client/src/pages/MemberHub.tsx

## Required Reading Order

1. `START-HERE.md`
2. `governance/cib/generated/CIB-APP-MEMBER-DASH-001-CYCLE-2.md`
3. `governance/rmp/MAIN_APP-IMPLEMENTATION-AUTHORITY.md`
4. `governance/execution-derivation/EXECUTION-DERIVATION.md`
5. `governance/icm/generated/ICM-APP-REALIZATION-002H.md`

## Contract Rule

Use only the authoritative contracts and Repository Truth contained in this
package. Do not invent APIs, schemas, authorities, compatibility contracts,
fallback contracts, or additional mutation scope.
