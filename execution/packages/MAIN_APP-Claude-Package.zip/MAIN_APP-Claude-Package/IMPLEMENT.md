# APP-MEMBER-DASH-001 — IMPLEMENTATION REQUEST

## STATUS

EXECUTE AFTER PIC PACKAGE SYNCHRONIZATION

## AUTHORITY

MAIN_APP

## TASK

APP-MEMBER-DASH-001

## CYCLE

2

## REPOSITORY

Main Application / Execution Runtime Repository (APP-RUNTIME-01)

## PRODUCTION SURFACE

client/src/pages/MemberHub.tsx

## INPUT

The generated PIC package is the sole implementation input.

Read and synchronize the governance artifacts in the package before mutation.

## EXECUTION BOUNDARY

Implement only the Founder-approved APP-MEMBER-DASH-001 Cycle-2 contract.

Respect all protected surfaces, concurrent-WIP protections, authoritative
backend contracts, mutation boundaries, acceptance criteria, hard stops, and
final-boundary restrictions contained in the CIB.

Do not commit, push, or deploy.
